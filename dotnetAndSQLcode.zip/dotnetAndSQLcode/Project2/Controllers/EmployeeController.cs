﻿// EmployeeController.cs
using Microsoft.AspNetCore.Mvc;
using Project2.Data;

namespace HRProject.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(int employeeId)
        {
            var employee = _context.Employee
                .FirstOrDefault(e => e.Id == employeeId);

            if (employee == null)
            {
                ViewBag.ErrorMessage = "Employee not found";
                return View();
            }

            var rootManagerId = _context.Employee
                .Where(e => e.Id == employeeId)
                .Select(e => e.RootManagerId)
                .FirstOrDefault();

            ViewBag.RootManagerId = rootManagerId;

            var employeesUnderRootManager = _context.Employee
                .Where(e => e.RootManagerId == rootManagerId)
                .ToList();

            ViewBag.EmployeesUnderRootManager = employeesUnderRootManager;

            return View(employee);
        }
    }
}
