﻿using Project2.Models;
using Microsoft.EntityFrameworkCore;

namespace Project2.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<Employee> Employee { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder);

        //    // Define the foreign key relationship for Manager
        //    modelBuilder.Entity<Employee>()
        //        .HasOne(e => e.Manager)
        //        .WithMany()
        //        .HasForeignKey(e => e.ManagerId)
        //        .OnDelete(DeleteBehavior.Restrict);
        //}
    }
}
