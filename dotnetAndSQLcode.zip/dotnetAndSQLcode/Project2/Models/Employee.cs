﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Project2.Models
{
    public class Employee
    {
		[Key]
		public int Id { get; set; }

		[MaxLength(100)]
		public string Name { get; set; }

		public DateTime? JoinDate { get; set; }

		public string Designation { get; set; }

		public decimal? Salary { get; set; }

		public bool? IsBonusAdded { get; set; }

		public int? ManagerId { get; set; }

		public int? RootManagerId { get; set; }

		public decimal? SalaryWithBonus { get; set; }

		public DateTime? RootManagerJoiningDate { get; set; }

		public DateTime? ManagerJoiningDate { get; set; }
	}
}
