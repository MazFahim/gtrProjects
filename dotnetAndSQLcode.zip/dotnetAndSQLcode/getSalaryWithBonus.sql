UPDATE [Accounting].[dbo].[Employee]
SET [SalaryWithBonus] = [Salary] + 

    CASE
        -- Condition 1
        WHEN [RootManagerJoiningDate] <= DATEADD(YEAR, -4, GETDATE()) AND YEAR(GETDATE()) % 4 = 0
            THEN 10000 + 
                CASE WHEN [JoinDate] < [ManagerJoiningDate] THEN 2000 ELSE 0 END
        -- Condition 2
        WHEN [RootManagerJoiningDate] <= DATEADD(YEAR, -4, GETDATE()) AND YEAR(GETDATE()) % 4 <> 0
            THEN 8000 + 
                CASE WHEN [JoinDate] >= [ManagerJoiningDate] THEN 1000 ELSE 0 END
        -- Condition 3
        WHEN [RootManagerJoiningDate] > DATEADD(YEAR, -4, GETDATE()) AND YEAR(GETDATE()) % 4 = 0
            THEN 5000 + 
                CASE WHEN [JoinDate] < [ManagerJoiningDate] THEN 1000 ELSE 0 END
        -- Condition 4
        WHEN [RootManagerJoiningDate] > DATEADD(YEAR, -4, GETDATE()) AND YEAR(GETDATE()) % 4 <> 0
            THEN 3000 + 
                CASE WHEN [JoinDate] >= [ManagerJoiningDate] THEN 500 ELSE 0 END
        ELSE 0 
    END

WHERE [IsBonusAdded] = 1;
