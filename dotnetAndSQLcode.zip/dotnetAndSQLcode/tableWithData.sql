-- Table creation script
CREATE TABLE [dbo].[Employee](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [Name] [varchar](100) NULL,
    [JoinDate] [datetime] NULL,
    [Designation] [varchar](100) NULL,
    [Salary] [decimal](18, 2) NULL,
    [IsBonusAdded] [bit] NULL,
    [ManagerId] [int] NULL,
    [RootManagerId] [int] NULL,
    [SalaryWithBonus] [decimal](18, 2) NULL,
    [RootManagerJoiningDate] [datetime] NULL,
    [ManagerJoiningDate] [date] NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
    [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY];
GO

-- Data insertion script
INSERT INTO [dbo].[Employee] ([Id], [Name], [JoinDate], [Designation], [Salary], [IsBonusAdded], [ManagerId], [RootManagerId], [SalaryWithBonus], [RootManagerJoiningDate], [ManagerJoiningDate])
VALUES
(1, 'John', '2010-01-01 00:00:00.000', 'General Manager', 500000.00, 0, NULL, 1, 500000.00, NULL, NULL),
(2, 'Ron', '2011-02-02 00:00:00.000', 'Manager', 500000.00, 1, 1, 1, 510000.00, '2010-01-01 00:00:00.000', '2010-01-01'),
(3, 'Doe', '2009-04-04 00:00:00.000', 'Director', 700000.00, 0, NULL, 3, 700000.00, NULL, NULL),
(4, 'Nicolas', '2012-05-05 00:00:00.000', 'CTO', 600000.00, 0, NULL, 4, 600000.00, NULL, NULL),
(5, 'Huma', '2011-05-05 00:00:00.000', 'HR Director', 80000.00, 1, 3, 3, 90000.00, '2009-04-04 00:00:00.000', '2009-04-04'),
(6, 'Joya', '2011-07-10 00:00:00.000', 'HR Executive', 30000.00, 1, 5, 3, 40000.00, '2009-04-04 00:00:00.000', '2011-05-05'),
(7, 'Jason', '2013-02-10 00:00:00.000', 'HR Executive', 30000.00, 0, 5, 3, 30000.00, '2009-04-04 00:00:00.000', '2011-05-05'),
(8, 'Josh', '2012-01-10 00:00:00.000', 'Team Lead', 40000.00, 1, 4, 4, 52000.00, '2012-05-05 00:00:00.000', '2012-05-05'),
(9, 'Stardum', '2010-01-02 00:00:00.000', 'Team Lead', 40000.00, 1, 4, 4, 52000.00, '2012-05-05 00:00:00.000', '2012-05-05'),
(10, 'Umaer', '2010-02-01 00:00:00.000', 'Senior Software Engineer', 30000.00, 1, 8, 4, 42000.00, '2012-05-05 00:00:00.000', '2012-01-10'),
(11, 'Uzair', '2010-01-03 00:00:00.000', 'Senior Software Egineer', 30000.00, 0, 8, 4, 32000.00, '2012-05-05 00:00:00.000', '2012-01-10'),
(12, 'Kate', '2010-01-10 00:00:00.000', 'Engineer', 20000.00, 1, 9, 4, 30000.00, '2010-01-01 00:00:00.000', '2010-01-02'),
(13, 'Harish', '2010-10-10 00:00:00.000', 'Engineer', 20000.00, 1, 9, 4, 30000.00, '2010-01-01 00:00:00.000', '2010-01-02'),
(14, 'Jack', '2014-10-10 00:00:00.000', 'Office Executive', 15000.00, 0, 2, 1, 15000.00, '2010-01-01 00:00:00.000', '2011-02-02'),
(15, 'Jane', '2009-10-10 00:00:00.000', 'Office Executive', 15000.00, 1, 2, 1, 27000.00, '2010-01-01 00:00:00.000', '2011-02-02'),
(16, 'Hun', '2009-10-10 00:00:00.000', 'Office Executive', 15000.00, 1, 2, 1, 27000.00, '2010-01-01 00:00:00.000', '2011-02-02');
